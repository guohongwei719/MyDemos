[深入理解 iOS 事件机制](https://mp.weixin.qq.com/s/SWcCXL0o05tFfLbSjS49Ag)
[iOS 事件(UITouch、UIControl、UIGestureRecognizer)传递机制](https://www.jianshu.com/p/df86508e2811)
